<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'xxxxx');

/** MySQL database username */
define('DB_USER', 'xxxxx');

/** MySQL database password */
define('DB_PASSWORD', 'xxxxx');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '3s.pXun1[yXsmh)}k^XJF@Jvg>ro9`m T}Y){4umvJU){0QRq,1c*Pr75+6GqrxP');
define('SECURE_AUTH_KEY',  '6I-rAuK3UCY-$g5=NFbT%UcKy5VndtGMA$g*7BJrRR=(*P{$>f:3D8vQ!:2 p@+=');
define('LOGGED_IN_KEY',    '`>z~Ql*&0.e{RUZdg0@)`=X1:8Nd>F|~N{,PzXz3W$3xskiyB)x{E6roRRxezYeL');
define('NONCE_KEY',        '7dx4z:pZSu7Co=m&|kX|B%M`Fnt,7!3{Jq+h<mCZMBFqQT@O~)lnivNk{!NeG8k,');
define('AUTH_SALT',        '%bHUurI@B+xJ~uyI!UeO~Z57^h%(fi}+Pp|(y-.B (P_ozH0o(8jxKx~k$,u`@Ht');
define('SECURE_AUTH_SALT', 'Fim1%zJP9x.V-jA>kiX<zwJSKhC2,AbFbdZGkxx<xW&!6`*6uRO#SZsm,lr/wd` ');
define('LOGGED_IN_SALT',   'CE6bOK_rpi|&6X{ob]3Q1covu88Zq@S]%@okV:X}8fx@%*Fr_^0&3Jv7Z%!erwzF');
define('NONCE_SALT',       'L?{WE+GNRzpRplI%5Fa8Pyvn@xcg1T&)[Ox-THQ4,;)VmXPeiS7:J&y~AAiI:df|');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
