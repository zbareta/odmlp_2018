<!--
Zeljko Bareta - IM Associate, Belgrade, Serbia
work e-mail:	BARETA@unhcr.org
private e-mail:	zbareta@gmail.com
mobile:			+38163 366 158
skype: 			zeljko.bareta
-->
<?php ob_start(); ?>
<html lang="en">
	<head>
		<?php include("functions.php");?>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<title>Centre Profiling - Data Management Portal</title>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
		<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css">
		<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.4.js"></script>
		<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
		<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
		<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
		<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
		<script type="text/javascript" language="javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
		<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
		<script type="text/javascript" language="javascript" src="//cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function() {
			    
			    $('#data').DataTable( {
			        dom: 'Bfrtip',
			        lengthMenu: [
			            [ 10, 50, 100, -1 ],
			            [ '10 rows', '50 rows', '100 rows', 'Show all' ]
			        ],
			        buttons: [
			            'pageLength', 'copy', 'excel'
			        ]
			    } );
		    // Setup - add a text input to each footer cell
		    $('#data tfoot th').each( function () {
		        var title = $(this).text();
		        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
		    } );
		 
		    // DataTable
		    var table = $('#data').DataTable();
		 
		    // Apply the search
		    table.columns().every( function () {
		        var that = this;
		 
		        $( 'input', this.footer() ).on( 'keyup change', function () {
		            if ( that.search() !== this.value ) {
		                that
		                    .search( this.value )
		                    .draw();
		            }
		        } );
		    } );
		} );

		</script>
		<style>
			tfoot {
			    display: table-header-group;
}
			tfoot input {
		      width: 100%;
		      padding: 3px;
		      box-sizing: border-box;
		    }
			#loader {
			  position: absolute;
			  left: 50%;
			  top: 50%;
			  z-index: 1;
			  width: 150px;
			  height: 150px;
			  margin: -75px 0 0 -75px;
			  border: 16px solid #0072bc;
			  border-radius: 50%;
			  border-top: 16px solid #000000;
			  width: 120px;
			  height: 120px;
			  -webkit-animation: spin 2s linear infinite;
			  animation: spin 2s linear infinite;
			}
			@-webkit-keyframes spin {
			  0% { -webkit-transform: rotate(0deg); }
			  100% { -webkit-transform: rotate(360deg); }
			}

			@keyframes spin {
			  0% { transform: rotate(0deg); }
			  100% { transform: rotate(360deg); }
			}

			/* Add animation to "page content" */
			.animate-bottom {
			  position: relative;
			  -webkit-animation-name: animatebottom;
			  -webkit-animation-duration: 1s;
			  animation-name: animatebottom;
			  animation-duration: 1s
			}
			@-webkit-keyframes animatebottom {
			  from { bottom:-100px; opacity:0 } 
			  to { bottom:0px; opacity:1 }
			}
			@keyframes animatebottom { 
			  from{ bottom:-100px; opacity:0 } 
			  to{ bottom:0; opacity:1 }
			}
			#myDiv {
			  display: none;
			  text-align: center;
			}
		</style>
		<?php
		
		if (!isset($_POST['username'])){?>
		<div align="center">
			<img src="ODMLP_vertical.png" alt="AGDM Logo" style="max-width: 100%; height: auto; align">
			<br><br>
			<form action="" method="post">
				Username:<br>
				<input style="width: 200px"  type="text" name="username"><br><br>
				Password:<br>
				<input style="width: 200px" type="password" name="password"><br><br>
				<input type="submit" value="login">
			</form>
		<p style="font-style: italic;">Centre Profiling, Online Secure Platform for Viewing, Updating and Exporting Data</br>
		ODMLP Project, Zeljko Bareta 768<br>
		Return to the <a href="https://idna.in.rs/odmlp/">online platform</a></p>
		</div>
		<div align="center" style="color: red">
		<?php if (isset($_POST["username"])){echo $error;}?>
		</div>
		<?php
		}else{
		$username = test_input($_POST['username']);
		$password = test_input($_POST['password']);
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_URL, "https://kobocat.unhcr.org/bareta/forms/aVC7UaCzNnKgRWUhhUSjDK/api");
		curl_setopt($curl, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$resp = curl_exec($curl);
		$forms = json_decode($resp,true);
		if($errno = curl_errno($curl)) {
			$error_message = curl_strerror($errno);
			echo "Error: Could not connect to KoBo database. Please try again later.";
		}
		curl_close($curl);?>
	</head>
	<body style="font-family:arial; font-size: 13; width:80%; margin:20 auto;" onload="myFunction()">

		<div id="loader"></div>
		<div style="display:none;" id="myDiv" class="animate-bottom"></div>
		<script>
			var myVar;
			function myFunction() {
			    myVar = setTimeout(showPage, 1000);
			}
			function showPage() {
			  document.getElementById("loader").style.display = "none";
			  document.getElementById("myDiv").style.display = "block";
			}
		</script>
		<img src="ODMLP_horizontal.png" alt="BPM Logo" style="max-width: 100%; height: auto;">
		</br></br>
		<form method="GET" action="index.php">
			<input type="hidden" name="action" value="Logged_out" ?>
			<input type="submit" value='Log Out'></form>
		<div>
		<!--<form method="POST" action="dashboard.php">
			<input type="hidden" name="url" value="https://kobocat.unhcr.org/agdm_serbia/forms/aepCjduG4RTxrtvUh9AL8C/api">
			<input type="hidden" name="username" value=<?php //echo $_POST['username'] ?>>
			<input type="hidden" name="password" value=<?php //echo $_POST['password'] ?>>
			<input type="submit" value='View Dashboard'></form>-->
		<div>
		    <p>In order to update/delete records by clicking on the Centre ID, you need to be logged in into <a href="https://kobo.unhcr.org/" target="_blank">KoBo Toolbox</a>.<br>(username: <strong>odmlp_768</strong>, password: <strong>768</strong>) </p>
			<table id="data" class="display" cellspacing="0" width="100%" style="font-family:arial; font-size: 13">
				<thead>
					<tr>
						<th>Centre ID</th>
						<th>Centre Name</th>
						<th>Address</th>
						<th>Phone Number</th>
						<th>E-mail</th>
						<th>Occupancy</th>
						<th>Capacity</th>
						<th>Fire Safety</th>
						<th>Adequatly Lit</th>
						<th>No Physical Risks</th>
						<th>Fence</th>
						<th>Security Personnel</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Centre ID</th>
						<th>Centre Name</th>
						<th>Address</th>
						<th>Phone Number</th>
						<th>E-mail</th>
						<th>Occupancy</th>
						<th>Capacity</th>
						<th>Fire Safety</th>
						<th>Adequatly Lit</th>
						<th>No Physical Risks</th>
						<th>Fence</th>
						<th>Security Personnel</th>
					</tr>
				</tfoot>
				<tbody>
				<?php
					$traffic_yellow = "<img src='light_yellow.png' alt='Yellow Light'>";
					$traffic_red = "<img src='light_red.png' alt='Red Light'>";
					$traffic_green = "<img src='light_green.png' alt='Green Light'>";

					if (!is_array($forms)){
						ob_end_clean();
						header('Location: index.php');
						ob_end_flush();
						;
					}
					foreach($forms as $item){?>
					<tr style="font-size: 12; text-align: center;">
						<td><a href=<?php echo substr("https://kobocat.unhcr.org/bareta/forms/aVC7UaCzNnKgRWUhhUSjDK/api", 0, -4) . "/instance#/"?><?php echo $item['_id']?>><?php echo $item['_id'];?></a></td>
						<td><?php if(isset($item['Centre_Name'])){echo strtoupper($item['Centre_Name']);}else echo "No Data";?></td>
						<td><?php if(isset($item['Address'])){echo $item['Address'];}else echo "No Data";?></td>
						<td><?php if(isset($item['Phone_Number'])){echo strtoupper($item['Phone_Number']);}else echo "No Data";?></td>
						<td><?php if(isset($item['E_mail'])){echo $item['E_mail'];}else echo "No Data";?></td>
						<td><?php if(isset($item['Occupancy'])){echo strtoupper($item['Occupancy']);}else echo "No Data";?></td>
						<td><?php if(isset($item['Capacity'])){echo strtoupper($item['Capacity']);}else echo "No Data";?></td>
						
						<td><?php if(isset($item['group_cj2dd88/Fire_Safety_Ensured'])){echo strtoupper($item['group_cj2dd88/Fire_Safety_Ensured']) . "<br><br>"; if($item['group_cj2dd88/Fire_Safety_Ensured']=='yes') echo $traffic_green; if($item['group_cj2dd88/Fire_Safety_Ensured']=='partially') echo $traffic_yellow; if($item['group_cj2dd88/Fire_Safety_Ensured']=='no') echo $traffic_red;}else echo "No Data";?></td>
						
						<td><?php if(isset($item['group_cj2dd88/Centre_Adequately_Lit'])){echo strtoupper($item['group_cj2dd88/Centre_Adequately_Lit']) . "<br><br>"; if($item['group_cj2dd88/Centre_Adequately_Lit']=='yes') echo $traffic_green; if($item['group_cj2dd88/Centre_Adequately_Lit']=='partially') echo $traffic_yellow; if($item['group_cj2dd88/Centre_Adequately_Lit']=='no') echo $traffic_red;}else echo "No Data";?></td>
						
						<td><?php if(isset($item['group_cj2dd88/Physical_Risks'])){echo strtoupper($item['group_cj2dd88/Physical_Risks']) . "<br><br>"; if($item['group_cj2dd88/Physical_Risks']=='yes') echo $traffic_green; if($item['group_cj2dd88/Physical_Risks']=='partially') echo $traffic_yellow; if($item['group_cj2dd88/Physical_Risks']=='no') echo $traffic_red;}else echo "No Data";?></td>
						
						<td><?php if(isset($item['group_cj2dd88/Centre_Secured_with_a_Fence'])){echo strtoupper($item['group_cj2dd88/Centre_Secured_with_a_Fence']) . "<br><br>"; if($item['group_cj2dd88/Centre_Secured_with_a_Fence']=='yes') echo $traffic_green; if($item['group_cj2dd88/Centre_Secured_with_a_Fence']=='partially') echo $traffic_yellow; if($item['group_cj2dd88/Centre_Secured_with_a_Fence']=='no') echo $traffic_red;}else echo "No Data";?></td>
						
						<td><?php if(isset($item['group_cj2dd88/Security_Personnel_Present'])){echo strtoupper($item['group_cj2dd88/Security_Personnel_Present']) . "<br><br>"; if($item['group_cj2dd88/Security_Personnel_Present']=='yes') echo $traffic_green; if($item['group_cj2dd88/Security_Personnel_Present']=='partially') echo $traffic_yellow; if($item['group_cj2dd88/Security_Personnel_Present']=='no') echo $traffic_red;}else echo "No Data";?></td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
		<?php } ?>
	</body>
</html>